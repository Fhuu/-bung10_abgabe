class State{
    constructor() {
        this.state = 'BEGIN';
    }

    reset() {
        this.state = 'BEGIN';
    }
}